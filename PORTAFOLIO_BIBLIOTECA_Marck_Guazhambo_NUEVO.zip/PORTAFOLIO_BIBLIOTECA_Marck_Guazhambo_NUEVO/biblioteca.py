"""Sistema de biblioteca digital. Autor: Marck Guazhambo."""
from datetime import date
from pathlib import Path

CARPETA = Path(__file__).parent
LIBROS = CARPETA / "libros.txt"
PRESTAMOS = CARPETA / "prestamos.txt"

def leer(ruta):
    if not ruta.exists():
        return []
    return [linea.split("|") for linea in ruta.read_text(encoding="utf-8").splitlines() if linea.strip()]

def guardar(ruta, filas):
    texto = "\n".join("|".join(fila) for fila in filas)
    ruta.write_text(texto + ("\n" if texto else ""), encoding="utf-8")

def texto(mensaje):
    while True:
        valor = input(mensaje).strip()
        if valor and "|" not in valor:
            return valor
        print("Escribe un valor válido.")

def entero(mensaje):
    while True:
        try:
            return int(input(mensaje))
        except ValueError:
            print("Escribe un número entero.")

def cargar():
    libros = [{"id": int(i), "titulo": t, "autor": a, "estado": e} for i, t, a, e in leer(LIBROS)]
    prestamos = [{"id": int(i), "libro": int(l), "persona": p, "fecha": f, "estado": e}
                 for i, l, p, f, e in leer(PRESTAMOS)]
    return libros, prestamos

def guardar_todo(libros, prestamos):
    guardar(LIBROS, [[str(x["id"]), x["titulo"], x["autor"], x["estado"]] for x in libros])
    guardar(PRESTAMOS, [[str(x["id"]), str(x["libro"]), x["persona"], x["fecha"], x["estado"]] for x in prestamos])

def listar(libros):
    print("\nID   TÍTULO                         AUTOR                     ESTADO")
    print("-" * 70)
    for x in libros:
        print(f"{x['id']:<4} {x['titulo']:<30} {x['autor']:<25} {x['estado']}")
    print(f"Total: {len(libros)}")

def registrar(libros):
    nuevo = max((x["id"] for x in libros), default=0) + 1
    libros.append({"id": nuevo, "titulo": texto("Título: "), "autor": texto("Autor: "), "estado": "Disponible"})
    print("Libro registrado.")

def buscar(libros):
    palabra = texto("Buscar título: ").casefold()
    listar([x for x in libros if palabra in x["titulo"].casefold()])

def prestar(libros, prestamos):
    codigo = entero("ID del libro: ")
    libro = next((x for x in libros if x["id"] == codigo), None)
    if not libro or libro["estado"] != "Disponible":
        print("Libro inexistente o no disponible.")
        return
    prestamos.append({"id": max((x["id"] for x in prestamos), default=0) + 1, "libro": codigo,
                      "persona": texto("Estudiante: "), "fecha": date.today().isoformat(), "estado": "Activo"})
    libro["estado"] = "Prestado"
    print("Préstamo registrado.")

def devolver(libros, prestamos):
    codigo = entero("ID del libro: ")
    libro = next((x for x in libros if x["id"] == codigo), None)
    prestamo = next((x for x in prestamos if x["libro"] == codigo and x["estado"] == "Activo"), None)
    if not libro or not prestamo:
        print("No hay préstamo activo.")
        return
    libro["estado"], prestamo["estado"] = "Disponible", "Devuelto"
    print("Devolución registrada.")

def reporte(libros, prestamos):
    ocupados = sum(x["estado"] == "Prestado" for x in libros)
    activos = sum(x["estado"] == "Activo" for x in prestamos)
    porcentaje = ocupados * 100 / len(libros) if libros else 0
    print(f"\nLibros: {len(libros)} | Disponibles: {len(libros)-ocupados} | Prestados: {ocupados}")
    print(f"Préstamos: {len(prestamos)} | Activos: {activos} | Ocupación: {porcentaje:.1f}%")

def main():
    libros, prestamos = cargar()
    while True:
        print("\n=== BIBLIOTECA ===\n1 Registrar  2 Listar  3 Buscar  4 Prestar\n5 Devolver   6 Reporte  7 Salir")
        opcion = input("Opción: ").strip()
        if opcion == "1": registrar(libros)
        elif opcion == "2": listar(libros)
        elif opcion == "3": buscar(libros)
        elif opcion == "4": prestar(libros, prestamos)
        elif opcion == "5": devolver(libros, prestamos)
        elif opcion == "6": reporte(libros, prestamos)
        elif opcion == "7": guardar_todo(libros, prestamos); print("Datos guardados."); break
        else: print("Opción no válida.")

if __name__ == "__main__":
    main()
