PORTAFOLIO DE BIBLIOTECA
Autor: Marck Guazhambo
Implementación creada desde cero.
Ejecución: python biblioteca.py
