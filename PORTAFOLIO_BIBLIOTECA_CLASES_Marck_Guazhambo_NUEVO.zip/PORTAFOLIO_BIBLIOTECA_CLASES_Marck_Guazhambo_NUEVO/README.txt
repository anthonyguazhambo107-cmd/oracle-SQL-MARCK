PORTAFOLIO DE BIBLIOTECA ORIENTADO A OBJETOS

Autor: Marck Guazhambo
Descripción: sistema de biblioteca implementado desde cero con clases.

Ejecución:
    python sistema_biblioteca.py
