"""Biblioteca digital orientada a objetos.

Autor: Marck Guazhambo
Implementación creada desde cero.
"""

from datetime import date
from pathlib import Path


class Libro:
    def __init__(self, codigo, titulo, autor, estado="Disponible"):
        self.codigo = codigo
        self.titulo = titulo
        self.autor = autor
        self.estado = estado


class Prestamo:
    def __init__(self, numero, codigo_libro, estudiante, fecha, estado="Activo"):
        self.numero = numero
        self.codigo_libro = codigo_libro
        self.estudiante = estudiante
        self.fecha = fecha
        self.estado = estado


class Biblioteca:
    def __init__(self, carpeta=None):
        self.carpeta = Path(carpeta) if carpeta else Path(__file__).parent
        self.archivo_libros = self.carpeta / "libros.txt"
        self.archivo_prestamos = self.carpeta / "prestamos.txt"
        self.libros = self._leer_libros()
        self.prestamos = self._leer_prestamos()

    def _leer_lineas(self, ruta):
        if not ruta.exists():
            return []
        return [linea.split("|") for linea in ruta.read_text(encoding="utf-8").splitlines() if linea.strip()]

    def _leer_libros(self):
        return [Libro(int(codigo), titulo, autor, estado)
                for codigo, titulo, autor, estado in self._leer_lineas(self.archivo_libros)]

    def _leer_prestamos(self):
        return [Prestamo(int(numero), int(codigo), estudiante, fecha, estado)
                for numero, codigo, estudiante, fecha, estado in self._leer_lineas(self.archivo_prestamos)]

    def guardar(self):
        libros = [f"{x.codigo}|{x.titulo}|{x.autor}|{x.estado}" for x in self.libros]
        prestamos = [f"{x.numero}|{x.codigo_libro}|{x.estudiante}|{x.fecha}|{x.estado}" for x in self.prestamos]
        self.archivo_libros.write_text("\n".join(libros) + ("\n" if libros else ""), encoding="utf-8")
        self.archivo_prestamos.write_text("\n".join(prestamos) + ("\n" if prestamos else ""), encoding="utf-8")

    @staticmethod
    def texto(mensaje):
        while True:
            valor = input(mensaje).strip()
            if valor and "|" not in valor:
                return valor
            print("Escribe un valor válido sin el carácter |.")

    @staticmethod
    def entero(mensaje):
        while True:
            try:
                return int(input(mensaje))
            except ValueError:
                print("Escribe un número entero.")

    def por_codigo(self, codigo):
        return next((libro for libro in self.libros if libro.codigo == codigo), None)

    def alta_libro(self):
        nuevo_codigo = max((libro.codigo for libro in self.libros), default=0) + 1
        libro = Libro(nuevo_codigo, self.texto("Título: "), self.texto("Autor: "))
        self.libros.append(libro)
        print(f"Libro registrado con código {nuevo_codigo}.")

    def listar(self, libros=None):
        libros = self.libros if libros is None else libros
        print(f"\n{'ID':<5}{'TÍTULO':<32}{'AUTOR':<25}ESTADO")
        print("-" * 78)
        for libro in libros:
            print(f"{libro.codigo:<5}{libro.titulo:<32}{libro.autor:<25}{libro.estado}")
        print(f"Total: {len(libros)}")

    def buscar(self):
        palabra = self.texto("Texto del título: ").casefold()
        resultados = [libro for libro in self.libros if palabra in libro.titulo.casefold()]
        self.listar(resultados) if resultados else print("No hubo coincidencias.")

    def prestar(self):
        codigo = self.entero("Código del libro: ")
        libro = self.por_codigo(codigo)
        if libro is None or libro.estado != "Disponible":
            print("El libro no existe o no está disponible.")
            return
        numero = max((p.numero for p in self.prestamos), default=0) + 1
        self.prestamos.append(Prestamo(numero, codigo, self.texto("Estudiante: "), date.today().isoformat()))
        libro.estado = "Prestado"
        print("Préstamo registrado.")

    def devolver(self):
        codigo = self.entero("Código del libro: ")
        libro = self.por_codigo(codigo)
        prestamo = next((p for p in self.prestamos if p.codigo_libro == codigo and p.estado == "Activo"), None)
        if libro is None or prestamo is None:
            print("No hay un préstamo activo para ese libro.")
            return
        libro.estado = "Disponible"
        prestamo.estado = "Devuelto"
        print("Devolución registrada.")

    def ver_prestamos(self):
        nombres = {libro.codigo: libro.titulo for libro in self.libros}
        print("\nPRÉSTAMOS")
        for prestamo in self.prestamos:
            print(f"#{prestamo.numero} | {nombres.get(prestamo.codigo_libro, 'Desconocido')} | "
                  f"{prestamo.estudiante} | {prestamo.fecha} | {prestamo.estado}")

    def reporte(self):
        prestados = sum(libro.estado == "Prestado" for libro in self.libros)
        activos = sum(p.estado == "Activo" for p in self.prestamos)
        porcentaje = prestados * 100 / len(self.libros) if self.libros else 0
        print("\nREPORTE GENERAL")
        print(f"Total de libros: {len(self.libros)}")
        print(f"Disponibles: {len(self.libros) - prestados}")
        print(f"Prestados: {prestados}")
        print(f"Préstamos registrados: {len(self.prestamos)}")
        print(f"Préstamos activos: {activos}")
        print(f"Porcentaje prestado: {porcentaje:.1f}%")

    def iniciar(self):
        opciones = {
            "1": self.alta_libro,
            "2": self.listar,
            "3": self.buscar,
            "4": self.prestar,
            "5": self.devolver,
            "6": self.ver_prestamos,
            "7": self.reporte,
        }
        while True:
            print("\n=== SISTEMA DE BIBLIOTECA ===")
            print("1 Registrar | 2 Catálogo | 3 Buscar | 4 Prestar")
            print("5 Devolver | 6 Préstamos | 7 Reporte | 8 Salir")
            opcion = input("Opción: ").strip()
            if opcion == "8":
                self.guardar()
                print("Datos guardados. Hasta pronto.")
                break
            funcion = opciones.get(opcion)
            funcion() if funcion else print("Opción no válida.")


if __name__ == "__main__":
    Biblioteca().iniciar()
